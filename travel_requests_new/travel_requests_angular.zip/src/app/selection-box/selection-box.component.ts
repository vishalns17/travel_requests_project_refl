import { Component } from '@angular/core';

@Component({
  selector: 'app-selection-box',
  templateUrl: './selection-box.component.html',
  styleUrl: './selection-box.component.css'
})
export class SelectionBoxComponent {

}
