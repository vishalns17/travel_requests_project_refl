import { Component } from '@angular/core';

@Component({
  selector: 'app-plain-navbar',
  templateUrl: './plain-navbar.component.html',
  styleUrl: './plain-navbar.component.css'
})
export class PlainNavbarComponent {

}
